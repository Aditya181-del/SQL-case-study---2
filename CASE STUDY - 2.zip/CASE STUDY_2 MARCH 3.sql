CREATE DATABASE MARCH_3 
USE MARCH_3

-- CREATING TABLES ACCORDING THE DATA AND VALUES RESPECTIVELY 

CREATE TABLE LOCATION (Location_ID NUMERIC(20), City VARCHAR(10));

INSERT INTO LOCATION VALUES (122, 'New York')
INSERT INTO LOCATION VALUES (123, 'Dallas')
INSERT INTO LOCATION VALUES (124, 'Chicago')INSERT INTO LOCATION VALUES (167, 'Boston')CREATE TABLE DEPARTMENT (Department_Id NUMERIC(20), Name NVARCHAR(50), Location_ID NUMERIC(20))INSERT INTO DEPARTMENT VALUES (10, 'Accounting', 122)INSERT INTO DEPARTMENT VALUES (20, 'Sales', 124)INSERT INTO DEPARTMENT VALUES (30, 'Research', 123)INSERT INTO DEPARTMENT VALUES (40, 'Operations ', 167)CREATE TABLE JOB (Job_ID NUMERIC(20), Designation NVARCHAR(50))INSERT INTO JOB VALUES (667, 'Clerk')INSERT INTO JOB VALUES (668, 'Staff')
INSERT INTO JOB VALUES (669, 'Analyst')
INSERT INTO JOB VALUES (670, 'Sales Person')
INSERT INTO JOB VALUES (671, 'Manager')
INSERT INTO JOB VALUES (672, 'President')

CREATE TABLE EMPLOYEE (Employee_Id NUMERIC(20), Last_Name NVARCHAR(50), First_Name NVARCHAR(50), 
Middle_Name NVARCHAR(50), Job_Id NUMERIC(20), Hire_Date DATE, Salary NUMERIC(20), Comm NUMERIC(20), Department_Id NUMERIC(20))

INSERT INTO EMPLOYEE VALUES (7369 ,'Smith' ,'John' ,'Q' ,667 ,'17-Dec-84' ,800 ,Null ,20)
INSERT INTO EMPLOYEE VALUES (7499 ,'Allen' ,'Kevin' ,'J' ,670 ,'20-Feb-85' ,1600 ,300 ,30)
INSERT INTO EMPLOYEE VALUES (755 ,'Doyle', 'Jean', 'K', 671, '04-Apr-85', 2850, Null, 30)
INSERT INTO EMPLOYEE VALUES (756 , 'Dennis', 'Lynn', 'S', 671, '15-May-85', 2750, Null, 30)
INSERT INTO EMPLOYEE VALUES (757 , 'Baker', 'Leslie', 'D', 671, '10-Jun-85', 2200, Null, 40)
INSERT INTO EMPLOYEE VALUES (7521 , 'Wark', 'Cynthia', 'D', 670, '22-Feb-85', 1250, 50, 30)-- SIMPLE QUERIES -- 1. List all the employee details.

SELECT * FROM EMPLOYEE

-- 2. List all the department details.

SELECT * FROM DEPARTMENT

-- 3. List all job details.

SELECT * FROM JOB

-- 4. List all the locations.
SELECT * FROM LOCATION 
-- 5. List out the First Name, Last Name, Salary, Commission for all Employees.

SELECT FIRST_NAME, LAST_NAME,SALARY,COMM FROM EMPLOYEE

-- 6. List out the Employee ID, Last Name, Department ID for all employees and alias Employee ID as "ID of the Employee", 
-- Last Name as "Name of the Employee", Department ID as "Dep_id".

SELECT EMPLOYEE_ID AS "ID of the Employee", LAST_NAME AS "Name of the Employee", DEPARTMENT_ID AS "Dep_id" FROM EMPLOYEE

-- 7. List out the annual salary of the employees with their names only

SELECT FIRST_NAME, LAST_NAME, SALARY FROM EMPLOYEE


-- WHERE CONDITION

-- 1. List the details about "Smith".

SELECT * FROM EMPLOYEE WHERE LAST_NAME = 'SMITH'

-- 2. List out the employees who are working in department 20.

SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID = 20

-- 3. List out the employees who are earning salary between 2000 and 3000.

SELECT * FROM EMPLOYEE WHERE SALARY BETWEEN 2000 AND 3000

-- 4. List out the employees who are working in department 10 or 20.

SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID IN (10,20)

-- 5. Find out the employees who are not working in department 10 or 30.

SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID NOT IN (10,20)

-- 6. List out the employees whose name starts with 'L'.

SELECT * FROM EMPLOYEE WHERE FIRST_NAME LIKE 'L%' OR LAST_NAME LIKE 'L%'

-- 7. List out the employees whose name starts with 'L' and ends with 'E'.

SELECT * FROM EMPLOYEE WHERE FIRST_NAME LIKE 'L%%E' 

-- 8. List out the employees whose name length is 4 and start with 'J'.

SELECT * FROM EMPLOYEE WHERE FIRST_NAME LIKE 'J___'

-- 9. List out the employees who are working in department 30 and draw the salaries more than 2500.

SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID = 30 AND SALARY > 2500

-- 10. List out the employees who are not receiving commission.

SELECT * FROM EMPLOYEE WHERE COMM IS NULL


-- ORDER BY Clause:

-- 1. List out the Employee ID and Last Name in ascending order based on the Employee ID.

SELECT EMPLOYEE_ID, LAST_NAME FROM EMPLOYEE 
ORDER BY EMPLOYEE_ID -- HERE MENTIONING ASC i.e., ASCENDING ORDER(AO) IS NOT MADATORY BECUASE AO IS A DEFAULT SORTING ORDER IN SQL 

-- 2. List out the Employee ID and Name in descending order based on salary.

SELECT EMPLOYEE_ID, FIRST_NAME, SALARY LAST_NAME FROM EMPLOYEE 
ORDER BY SALARY DESC -- HERE DESC IS MANDATORY TO MENTION BECAUSE IT'S NOT A DEFAULT SORTING ORDER 

-- 3. List out the employee details according to their Last Name in ascending-order.

SELECT * FROM EMPLOYEE 
ORDER BY LAST_NAME ASC

-- 4. List out the employee details according to their Last Name in ascending order and then Department ID in descending order.
SELECT * FROM EMPLOYEE
ORDER BY DEPARTMENT_ID DESC, LAST_NAME ASC


-- GROUP BY AND HAVING Clause:

-- 1. List out the department wise maximum salary, minimum salary and average salary of the employees.

SELECT MAX(SALARY) AS MAX_SAL, MIN(SALARY) AS MIN_SAL, AVG(SALARY) AS AVG_SAL FROM EMPLOYEE
GROUP BY DEPARTMENT_ID

-- 2. List out the job wise maximum salary, minimum salary and average salary of the employees.

SELECT  MAX(SALARY) AS MAX_SAL, MIN(SALARY) AS MIN_SAL, AVG(SALARY) AS AVG_SAL FROM EMPLOYEE
GROUP BY JOB_ID

-- 3. List out the number of employees who joined each month in ascending order.

SELECT MONTH(HIRE_DATE) AS JOINING_MONTH, COUNT(*) AS EMP_CNT FROM EMPLOYEE
GROUP BY MONTH(HIRE_DATE)
ORDER BY EMP_CNT ASC

-- 4. List out the number of employees for each month and year in ascending order based on the year and month.

SELECT MONTH(HIRE_DATE) AS MNT_CNT, YEAR(HIRE_DATE) AS YR_CNT, COUNT(*) AS EMP_CNT FROM EMPLOYEE
GROUP BY YEAR(HIRE_DATE), MONTH(HIRE_DATE)
ORDER BY YR_CNT, MNT_CNT

-- 5. List out the Department ID having at least four employees.

SELECT DEPARTMENT_ID, COUNT(*) AS EMP_CNT FROM EMPLOYEE
GROUP BY DEPARTMENT_ID 
HAVING COUNT(*) >= 4

-- 6. How many employees joined in February month.

SELECT MONTH(HIRE_DATE) AS JOIN_DATE, COUNT(*) AS EMP_CNT FROM EMPLOYEE
GROUP BY MONTH(HIRE_DATE)
HAVING MONTH(HIRE_DATE) = 2	

-- 7. How many employees joined in May or June month.

SELECT MONTH(HIRE_DATE) AS JOIN_DATE, COUNT(*) AS EMP_CNT FROM EMPLOYEE
GROUP BY MONTH(HIRE_DATE)
HAVING MONTH(HIRE_DATE) = 5 OR MONTH(HIRE_DATE) = 6

-- 8. How many employees joined in 1985?

SELECT YEAR(HIRE_DATE) AS HIRE_YR, COUNT(*) AS EMP_CNT FROM EMPLOYEE
GROUP BY YEAR(HIRE_DATE)
HAVING YEAR(HIRE_DATE) = 1985

-- 9. How many employees joined each month in 1985?

SELECT MONTH(HIRE_DATE) AS HIRE_PER_MNT, COUNT(*) AS EMP_CNT FROM EMPLOYEE
GROUP BY YEAR(HIRE_DATE), MONTH(HIRE_DATE)
HAVING YEAR(HIRE_DATE) = 1985

-- 10. How many employees were joined in April 1985?

SELECT MONTH(HIRE_DATE) AS HIRE_PER_MNT, COUNT(*) AS EMP_CNT FROM EMPLOYEE
GROUP BY YEAR(HIRE_DATE), MONTH(HIRE_DATE)
HAVING YEAR(HIRE_DATE) = 1985 AND MONTH(HIRE_DATE) = 5

-- 11. Which is the Department ID having greater than or equal to 3 employees joining in April 1985?

SELECT Department_ID, COUNT(*) AS Employee_Count FROM EMPLOYEE WHERE YEAR(HIRE_DATE) = 1985 AND MONTH(HIRE_DATE) = 4
GROUP BY Department_ID;


-- JOINS:

-- 1. List out employees with their department names.

SELECT E.EMPLOYEE_ID, E.FIRST_NAME, E.MIDDLE_NAME, E.LAST_NAME, D.NAME AS DEPARTMENT_NAME FROM EMPLOYEE AS E JOIN DEPARTMENT AS D ON D.DEPARTMENT_ID = E.DEPARTMENT_ID

-- 2. Display employees with their designations.

SELECT E.EMPLOYEE_ID, E.FIRST_NAME, E.MIDDLE_NAME, E.LAST_NAME, J.DESIGNATION FROM EMPLOYEE AS E JOIN JOB AS J ON J.JOB_ID = E.JOB_ID

-- 3. Display the employees with their department names and city.

SELECT E.EMPLOYEE_ID, E.FIRST_NAME, E.MIDDLE_NAME, E.LAST_NAME, D.NAME AS DEPARTMENT_NAME, L.CITY FROM EMPLOYEE AS E, 
DEPARTMENT AS D JOIN LOCATION AS L ON L.LOCATION_ID = D.LOCATION_ID 

-- 4. How many employees are working in different departments? Display with department names.

SELECT D.NAME AS DEPARTMENT_NAME, COUNT(E.EMPLOYEE_ID) AS EMP_CNT FROM 
EMPLOYEE AS E JOIN DEPARTMENT AS D ON D.DEPARTMENT_ID = E.DEPARTMENT_ID 
GROUP BY D.NAME

-- 5. How many employees are working in the sales department?
	
SELECT COUNT(E.EMPLOYEE_ID) AS EMP_CNT FROM EMPLOYEE AS E JOIN DEPARTMENT AS D ON D.DEPARTMENT_ID = E.DEPARTMENT_ID
WHERE D.NAME = 'SALES'

-- 6. Which is the department having greater than or equal to 3 employees and display the department names in ascending order.

SELECT D.Name AS DEPARTMENT_ID , COUNT(E.EMPLOYEE_ID) AS EMP_CNT FROM EMPLOYEE E JOIN DEPARTMENT D ON E.DEPARTMENT_ID = D.DEPARTMENT_ID
GROUP BY D.Name
HAVING COUNT(E.EMPLOYEE_ID) >= 3
ORDER BY D.Name 


-- 7. How many employees are working in 'Dallas'?

SELECT COUNT(E.EMPLOYEE_ID) AS EMPLOYEE_COUNT FROM EMPLOYEE E
JOIN DEPARTMENT D ON E.DEPARTMENT_ID = D.DEPARTMENT_ID
JOIN LOCATION L ON D.LOCATION_ID = L.LOCATION_ID
WHERE L.CITY = 'DALLAS';


-- 8. Display all employees in sales or operation departments

SELECT E.EMPLOYEE_ID, E.FIRST_NAME, E.LAST_NAME, D.NAME AS DEPARTMENT_NAME FROM EMPLOYEE E JOIN DEPARTMENT D ON E.DEPARTMENT_ID = D.DEPARTMENT_ID
WHERE D.NAME IN ('SALES', 'OPERATIONS');


-- CONDITIONAL STATEMENT

-- 1. Display the employee details with salary grades. Use conditional statement to create a grade column.

SELECT E.EMPLOYEE_ID, E.FIRST_NAME, E.LAST_NAME, E.SALARY, 
	CASE
		WHEN E.SALARY >= 2000 THEN 'A'
		WHEN E.SALARY BETWEEN 1000 AND 1999 THEN 'B'
		WHEN E.SALARY BETWEEN 100 AND 999 THEN 'C'
		ELSE 'E'
	END AS SALARY_GRADE
FROM EMPLOYEE AS E

-- 2. List out the number of employees grade wise. Use conditional statement to create a grade column.

SELECT  
	CASE
		WHEN SALARY >= 2000 THEN 'A'
		WHEN SALARY BETWEEN 1000 AND 1999 THEN 'B'
		WHEN SALARY BETWEEN 100 AND 999 THEN 'C'
		ELSE 'E'
	END AS SALARY_GRADE,
	COUNT(*) AS EMPLOYEE_COUNT
FROM EMPLOYEE 
GROUP BY 
	CASE
		WHEN SALARY >= 2000 THEN 'A'
		WHEN SALARY BETWEEN 1000 AND 1999 THEN 'B'
		WHEN SALARY BETWEEN 100 AND 999 THEN 'C'
		ELSE 'E'
	END
ORDER BY SALARY_GRADE

-- 3. Display the employee salary grades and the number of employees between 2000 to 5000 range of salary

SELECT  
	CASE
		WHEN SALARY >= 2000 THEN 'A'
		WHEN SALARY BETWEEN 1000 AND 1999 THEN 'B'
		WHEN SALARY BETWEEN 100 AND 999 THEN 'C'
		ELSE 'E'
	END AS SALARY_GRADE,
	COUNT(*) AS EMPLOYEE_COUNT
FROM EMPLOYEE 
WHERE SALARY BETWEEN 2000 AND 5000
GROUP BY 
	CASE
		WHEN SALARY >= 2000 THEN 'A'
		WHEN SALARY BETWEEN 1000 AND 1999 THEN 'B'
		WHEN SALARY BETWEEN 100 AND 999 THEN 'C'
		ELSE 'E'
	END
ORDER BY SALARY_GRADE


-- Subqueries:
-- 1. Display the employees list who got the maximum salary.

SELECT * FROM EMPLOYEE WHERE SALARY = (SELECT MAX(SALARY) FROM EMPLOYEE)

-- 2. Display the employees who are working in the sales department.

SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID = (SELECT DEPARTMENT_ID FROM DEPARTMENT WHERE NAME = 'SALES')

-- 3. Display the employees who are working as 'Clerk'.

SELECT * FROM EMPLOYEE WHERE JOB_ID = (SELECT JOB_ID FROM JOB WHERE DESIGNATION = 'CLERK')

-- 4. Display the list of employees who are living in 'Boston'.

SELECT * FROM EMPLOYEE WHERE DEPARTMENT_ID IN (SELECT DEPARTMENT_ID FROM DEPARTMENT 
WHERE LOCATION_ID = (SELECT LOCATION_ID FROM LOCATION WHERE CITY = 'BOSTON'))

-- 5. Find out the number of employees working in the sales department.

SELECT COUNT(*) AS EMPLOYEE_COUNT FROM EMPLOYEE
WHERE DEPARTMENT_ID = (SELECT DEPARTMENT_ID FROM DEPARTMENT WHERE NAME = 'SALES')

-- 6. Update the salaries of employees who are working as clerks on the basis of 10%.

UPDATE EMPLOYEE SET SALARY = SALARY * 1.10
WHERE JOB_ID = (SELECT JOB_ID FROM JOB WHERE DESIGNATION = 'CLERK')

-- 7. Display the second highest salary drawing employee details.

SELECT * FROM EMPLOYEE WHERE SALARY = (SELECT MAX(SALARY) FROM EMPLOYEE WHERE SALARY < (SELECT MAX(SALARY) FROM EMPLOYEE))

-- 8. List out the employees who earn more than every employee in department 30.

SELECT * FROM EMPLOYEE WHERE SALARY > (SELECT MAX(SALARY) FROM EMPLOYEE WHERE DEPARTMENT_ID = 30)

-- 9. Find out which department has no employees.

SELECT DEPARTMENT_ID, NAME FROM DEPARTMENT WHERE DEPARTMENT_ID NOT IN (SELECT DISTINCT DEPARTMENT_ID FROM EMPLOYEE)

-- 10. Find out the employees who earn greater than the average salary for their department.

SELECT * FROM EMPLOYEE E WHERE SALARY > (SELECT AVG(SALARY) FROM EMPLOYEE  WHERE DEPARTMENT_ID = E.DEPARTMENT_ID)
